import React from 'react'
import List from '../Component/List/List'
import Nav from '../Component/Nav/Nav'

function Home() {
  return (
    <div>
      <div><Nav></Nav></div>
      <div><List/></div>
      
      
    </div>
  )
}

export default Home
